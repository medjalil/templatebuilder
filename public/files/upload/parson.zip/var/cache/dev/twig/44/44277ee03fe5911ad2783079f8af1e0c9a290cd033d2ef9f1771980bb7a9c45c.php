<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* task/new.html.twig */
class __TwigTemplate_c147be5b8090c5fb48979f5c07b6cc1930cc851dc37c91e3729a36a7a651eca9 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "task/new.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "task/new.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "task/new.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Ajouter exercice";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/parsons.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/prettify.css"), "html", null, true);
        echo "\">
    <script src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/prettify.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "    <div class=\"row\">
        <div class=\"col-4\">
            <h1 class=\"h3 mb-3 font-weight-normal mt-4\">Ajouter exercice</h1>

            ";
        // line 15
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 15, $this->source); })()), 'form_start');
        echo "
            ";
        // line 16
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 16, $this->source); })()), 'widget');
        echo "
            <button class=\"btn btn-primary envoyer\">";
        // line 17
        echo twig_escape_filter($this->env, (((isset($context["button_label"]) || array_key_exists("button_label", $context))) ? (_twig_default_filter((isset($context["button_label"]) || array_key_exists("button_label", $context) ? $context["button_label"] : (function () { throw new RuntimeError('Variable "button_label" does not exist.', 17, $this->source); })()), "Enregistrer")) : ("Enregistrer")), "html", null, true);
        echo "</button>
            ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 18, $this->source); })()), 'form_end');
        echo "
        </div>
        <div class=\"col-8\">
            <h1 class=\"h3 mb-3 font-weight-normal mt-4\">Solution</h1>

            <div class=\"form-error\">
                ";
        // line 24
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 24, $this->source); })()), "solution", [], "any", false, false, false, 24), 'errors');
        echo "
            </div>
            <form id=\"addLineForm\">
                <div class=\"form-row\">
                    <div class=\"form-group mr-2\">
                        <label>Ligne</label>
                        <input type=\"text\" name=\"lineText\" id=\"lineText\" class=\"form-control mr-2\" placeholder=\"Ligne\" required/>
                    </div>
                    <div class=\"form-group mr-2\">
                        <label>Position</label>
                        <input type=\"number\" name=\"level\" id=\"level\" value=\"0\" class=\"form-control mr-2\" placeholder=\"Position\" min=\"0\" required/>
                    </div>
                    <div class=\"form-groups\">

                        <input type=\"submit\" value=\"Ajouter\"  class=\"btn btn-info mt-sm-4\"/>

                    </div>
                </div>
            </form>

            <div id=\"sortable\" class=\"sortable-code ml-0\">
                <p>Solution</p>

                <ul id=\"ul-sortable\" class=\"ui-sortable output\">
                    <br>
                </ul>
            </div>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 54
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 55
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/jquery.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/jquery-ui.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/jquery.ui.touch-punch.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/underscore-min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/lis.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/parsons.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/skulpt.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/skulpt-stdlib.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 64
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/prettify.js"), "html", null, true);
        echo "\"></script>
    <script>
        var tasks = [];
        var i = 0;
        var initial = \"\";
        // Ajouter ligne
        function addLine() {
            \$(\"#ul-sortable\").empty();
            initial = \"\"
            tasks.forEach(task => {
                let levels = \"\";
                levels = \"\\xa0\\xa0\".repeat(parseInt(task.level));
                let lineToAdd = levels + task.lineText + \"\\n\";
                initial = initial + lineToAdd;
                \$(\"#ul-sortable\").append(`<li
                                        id=\"sortablecodeline\${20}\"
                                        class=\"prettyprint lang-py\"
                                        style=\"margin-left: \${50 * task.level}px;\"
                                        >\${task.lineText}
                                        <span style=\"float:right;\" onclick=\"deleteItem(this,\${task.position})\" class=\"btn btn-danger btn-sm\">x</span>
                                    </li>`);
            })
            majSolutionInput(JSON.stringify(tasks))
        }
        // Mise à jour de champs solution
        function majSolutionInput(vl) {
            \$(\"#task_solution\").val(vl);
        }
        // code de parson
        function displayErrors(fb) {
            if (fb.errors.length > 0) {
                alert(fb.errors[0]);
            }
        }
        \$(document).ready(function () {
            var parson = new ParsonsWidget({
                sortableId: \"sortable\",
                trashId: \"sortableTrash\",
                max_wrong_lines: 1,
                feedback_cb: displayErrors,
            });
            //Supprimer le contenu de formulaire
            function clearAddLineForm() {
                \$(\"#lineText\").val(\"\");
                \$(\"#level\").val(\"0\");
            }
            //Event listner (controle des champs)
            \$(\"#addLineForm\").submit(function (e) {
                event.preventDefault();
                let line = {};
                let a = \$(this).serializeArray();
                a.forEach((aa) => {
                    line[aa.name] = aa.value;
                });
                tasks.push({lineText: line.lineText, level: line.level, position: i})
                addLine();
                i++;
                clearAddLineForm();
            });
        });
        // Supprimer ligne
        function deleteItem(a, ind) {
            \$(a).parent().remove();
            tasks = \$.grep(tasks, function (e) {
                return e.position != ind;
            });
            addLine();
            majSolutionInput(JSON.stringify(tasks));
        }
    </script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "task/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  239 => 64,  235 => 63,  231 => 62,  227 => 61,  223 => 60,  219 => 59,  215 => 58,  211 => 57,  207 => 56,  202 => 55,  192 => 54,  152 => 24,  143 => 18,  139 => 17,  135 => 16,  131 => 15,  125 => 11,  115 => 10,  103 => 8,  99 => 7,  95 => 6,  90 => 5,  80 => 4,  61 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Ajouter exercice{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('plugin/parson/parsons.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('plugin/parson/lib/prettify.css') }}\">
    <script src=\"{{asset('plugin/parson/lib/prettify.js')}}\"></script>
{% endblock %}
{% block body %}
    <div class=\"row\">
        <div class=\"col-4\">
            <h1 class=\"h3 mb-3 font-weight-normal mt-4\">Ajouter exercice</h1>

            {{ form_start(form) }}
            {{ form_widget(form) }}
            <button class=\"btn btn-primary envoyer\">{{ button_label|default('Enregistrer') }}</button>
            {{ form_end(form) }}
        </div>
        <div class=\"col-8\">
            <h1 class=\"h3 mb-3 font-weight-normal mt-4\">Solution</h1>

            <div class=\"form-error\">
                {{ form_errors(form.solution) }}
            </div>
            <form id=\"addLineForm\">
                <div class=\"form-row\">
                    <div class=\"form-group mr-2\">
                        <label>Ligne</label>
                        <input type=\"text\" name=\"lineText\" id=\"lineText\" class=\"form-control mr-2\" placeholder=\"Ligne\" required/>
                    </div>
                    <div class=\"form-group mr-2\">
                        <label>Position</label>
                        <input type=\"number\" name=\"level\" id=\"level\" value=\"0\" class=\"form-control mr-2\" placeholder=\"Position\" min=\"0\" required/>
                    </div>
                    <div class=\"form-groups\">

                        <input type=\"submit\" value=\"Ajouter\"  class=\"btn btn-info mt-sm-4\"/>

                    </div>
                </div>
            </form>

            <div id=\"sortable\" class=\"sortable-code ml-0\">
                <p>Solution</p>

                <ul id=\"ul-sortable\" class=\"ui-sortable output\">
                    <br>
                </ul>
            </div>
        </div>
    </div>
{% endblock %}
{% block javascripts %}
    {{ parent() }}
    <script src=\"{{asset('plugin/parson/lib/jquery.min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/jquery-ui.min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/jquery.ui.touch-punch.min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/underscore-min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/lis.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/parsons.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/skulpt.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/skulpt-stdlib.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/prettify.js')}}\"></script>
    <script>
        var tasks = [];
        var i = 0;
        var initial = \"\";
        // Ajouter ligne
        function addLine() {
            \$(\"#ul-sortable\").empty();
            initial = \"\"
            tasks.forEach(task => {
                let levels = \"\";
                levels = \"\\xa0\\xa0\".repeat(parseInt(task.level));
                let lineToAdd = levels + task.lineText + \"\\n\";
                initial = initial + lineToAdd;
                \$(\"#ul-sortable\").append(`<li
                                        id=\"sortablecodeline\${20}\"
                                        class=\"prettyprint lang-py\"
                                        style=\"margin-left: \${50 * task.level}px;\"
                                        >\${task.lineText}
                                        <span style=\"float:right;\" onclick=\"deleteItem(this,\${task.position})\" class=\"btn btn-danger btn-sm\">x</span>
                                    </li>`);
            })
            majSolutionInput(JSON.stringify(tasks))
        }
        // Mise à jour de champs solution
        function majSolutionInput(vl) {
            \$(\"#task_solution\").val(vl);
        }
        // code de parson
        function displayErrors(fb) {
            if (fb.errors.length > 0) {
                alert(fb.errors[0]);
            }
        }
        \$(document).ready(function () {
            var parson = new ParsonsWidget({
                sortableId: \"sortable\",
                trashId: \"sortableTrash\",
                max_wrong_lines: 1,
                feedback_cb: displayErrors,
            });
            //Supprimer le contenu de formulaire
            function clearAddLineForm() {
                \$(\"#lineText\").val(\"\");
                \$(\"#level\").val(\"0\");
            }
            //Event listner (controle des champs)
            \$(\"#addLineForm\").submit(function (e) {
                event.preventDefault();
                let line = {};
                let a = \$(this).serializeArray();
                a.forEach((aa) => {
                    line[aa.name] = aa.value;
                });
                tasks.push({lineText: line.lineText, level: line.level, position: i})
                addLine();
                i++;
                clearAddLineForm();
            });
        });
        // Supprimer ligne
        function deleteItem(a, ind) {
            \$(a).parent().remove();
            tasks = \$.grep(tasks, function (e) {
                return e.position != ind;
            });
            addLine();
            majSolutionInput(JSON.stringify(tasks));
        }
    </script>

{% endblock %}", "task/new.html.twig", "C:\\Users\\medab\\Desktop\\EDUCATION\\parson\\templates\\task\\new.html.twig");
    }
}
