<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* task/edit.html.twig */
class __TwigTemplate_90001267b250d2ec70fe6ec948258b9957bba082f29176fb1d504f0314789ec0 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "task/edit.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "task/edit.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "task/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Modifier exercice";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/parsons.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/prettify.css"), "html", null, true);
        echo "\">
    <script src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/prettify.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 11
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    <div class=\"row\">
        <div class=\"col-4\">
            <h1 class=\"h3 mb-3 font-weight-normal mt-4\">Modifier exercice</h1>

            ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 16, $this->source); })()), 'form_start');
        echo "
            ";
        // line 17
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 17, $this->source); })()), 'widget');
        echo "
            <button class=\"btn btn-primary envoyer\">";
        // line 18
        echo twig_escape_filter($this->env, (((isset($context["button_label"]) || array_key_exists("button_label", $context))) ? (_twig_default_filter((isset($context["button_label"]) || array_key_exists("button_label", $context) ? $context["button_label"] : (function () { throw new RuntimeError('Variable "button_label" does not exist.', 18, $this->source); })()), "Modifier")) : ("Modifier")), "html", null, true);
        echo "</button>
            ";
        // line 19
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 19, $this->source); })()), 'form_end');
        echo "
        </div>

        <p id=\"sol\" hidden>";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["task"]) || array_key_exists("task", $context) ? $context["task"] : (function () { throw new RuntimeError('Variable "task" does not exist.', 22, $this->source); })()), "solution", [], "any", false, false, false, 22), "html", null, true);
        echo "</p>
        <div class=\"col-8\">
            <h1 class=\"h3 mb-3 font-weight-normal mt-4\">Solution</h1>

            <div class=\"form-error\">
                ";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 27, $this->source); })()), "solution", [], "any", false, false, false, 27), 'errors');
        echo "
            </div>
            <form id=\"addLineForm\">
                <div class=\"form-row\">
                    <div class=\"form-group mr-2\">
                        <label>Ligne</label>
                        <input type=\"text\" name=\"lineText\" id=\"lineText\" class=\"form-control mr-2\" placeholder=\"Ligne\" required/>
                    </div>
                    <div class=\"form-group mr-2\">
                        <label>Position</label>
                        <input type=\"number\" name=\"level\" id=\"level\" value=\"0\" class=\"form-control mr-2\" placeholder=\"Position\" min=\"0\" required/>
                    </div>
                    <div class=\"form-groups\">

                        <input type=\"submit\" value=\"Ajouter\"  class=\"btn btn-info mt-sm-4\"/>

                    </div>
                </div>
            </form>

            <div id=\"sortable\" class=\"sortable-code ml-0\">
                <p>Solution</p>

                <ul id=\"ul-sortable\" class=\"ui-sortable output\">
                    <br>
                </ul>
            </div>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 57
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 58
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/jquery.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/jquery-ui.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/jquery.ui.touch-punch.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/underscore-min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/lis.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 64
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/parsons.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/skulpt.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/skulpt-stdlib.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/prettify.js"), "html", null, true);
        echo "\"></script>
    <script>
        var il = \$(\"#sol\").html();

        var tasks = JSON.parse(il);
        addOldLine();
        function htmlEntities(str) {
            return String(str)
                    .replace(/&/g, \"&amp;\")
                    .replace(/</g, \"&lt;\")
                    .replace(/>/g, \"&gt;\")
                    .replace(/\"/g, \"&quot;\");
        }
        var i = tasks.length;
        var initial = \"\";
        function addLine() {
            \$(\"#ul-sortable\").empty();
            initial = \"\"
            tasks.forEach(task => {
                let levels = \"\";
                levels = \"\\xa0\\xa0\".repeat(parseInt(task.level));
                let lineToAdd = levels + task.lineText + \"\\n\";
                initial = initial + lineToAdd;
                \$(\"#ul-sortable\").append(`<li
                                        id=\"sortablecodeline\${20}\"
                                        class=\"prettyprint lang-py\"
                                        style=\"margin-left: \${50 * task.level}px;\"
                                        >\${task.lineText}
                                        <span style=\"float:right;\" onclick=\"deleteItem(this,\${task.position})\" class=\"btn btn-danger btn-sm\">x</span>
                                    </li>`);
            })
            majSolutionInput(JSON.stringify(tasks))
        }
        function majSolutionInput(vl) {
            \$(\"#task_solution\").val(\"\");
            \$(\"#task_solution\").val(vl);
        }
        function displayErrors(fb) {
            if (fb.errors.length > 0) {
                alert(fb.errors[0]);
            }
        }
        function addOldLine() {
            \$(\"#ul-sortable\").empty();
            tasks.forEach(task => {
                let levels = \"\";
                levels = \"\\xa0\\xa0\".repeat(parseInt(task.level));
                let lineToAdd = levels + htmlEntities(task.lineText) + \"\\n\";
                \$(\"#ul-sortable\").append(`<li
                                        id=\"sortablecodeline\${20}\"
                                        class=\"prettyprint lang-py\"
                                        style=\"margin-left: \${50 * task.level}px;\"
                                        >\${task.lineText}
                            <span style=\"float:right;\" onclick=\"deleteItem(this,\${task.position})\" class=\"btn btn-danger btn-sm\">x</span>
                                    </li>`);
            })
        }
        \$(document).ready(function () {
            var parson = new ParsonsWidget({
                sortableId: \"sortable\",
                trashId: \"sortableTrash\",
                max_wrong_lines: 1,
                feedback_cb: displayErrors,
            });

            function clearAddLineForm() {
                \$(\"#lineText\").val(\"\");
                \$(\"#level\").val(\"0\");
            }

            \$(\"#addLineForm\").submit(function (e) {
                event.preventDefault();
                let line = {};
                let a = \$(this).serializeArray();
                a.forEach((aa) => {
                    line[aa.name] = aa.value;
                });
                tasks.push({lineText: line.lineText, level: line.level, position: i})
                addLine();
                i++;
                clearAddLineForm();
            });
        });
        function deleteItem(a, ind) {
            \$(a).parent().remove();
            tasks = \$.grep(tasks, function (e) {
                return e.position != ind;
            });
            addLine();
            majSolutionInput(JSON.stringify(tasks));
        }
    </script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "task/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  244 => 67,  240 => 66,  236 => 65,  232 => 64,  228 => 63,  224 => 62,  220 => 61,  216 => 60,  212 => 59,  207 => 58,  197 => 57,  157 => 27,  149 => 22,  143 => 19,  139 => 18,  135 => 17,  131 => 16,  125 => 12,  115 => 11,  103 => 9,  99 => 8,  95 => 7,  90 => 6,  80 => 5,  61 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Modifier exercice{% endblock %}

{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('plugin/parson/parsons.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('plugin/parson/lib/prettify.css') }}\">
    <script src=\"{{asset('plugin/parson/lib/prettify.js')}}\"></script>
{% endblock %}
{% block body %}
    <div class=\"row\">
        <div class=\"col-4\">
            <h1 class=\"h3 mb-3 font-weight-normal mt-4\">Modifier exercice</h1>

            {{ form_start(form) }}
            {{ form_widget(form) }}
            <button class=\"btn btn-primary envoyer\">{{ button_label|default('Modifier') }}</button>
            {{ form_end(form) }}
        </div>

        <p id=\"sol\" hidden>{{ task.solution }}</p>
        <div class=\"col-8\">
            <h1 class=\"h3 mb-3 font-weight-normal mt-4\">Solution</h1>

            <div class=\"form-error\">
                {{ form_errors(form.solution) }}
            </div>
            <form id=\"addLineForm\">
                <div class=\"form-row\">
                    <div class=\"form-group mr-2\">
                        <label>Ligne</label>
                        <input type=\"text\" name=\"lineText\" id=\"lineText\" class=\"form-control mr-2\" placeholder=\"Ligne\" required/>
                    </div>
                    <div class=\"form-group mr-2\">
                        <label>Position</label>
                        <input type=\"number\" name=\"level\" id=\"level\" value=\"0\" class=\"form-control mr-2\" placeholder=\"Position\" min=\"0\" required/>
                    </div>
                    <div class=\"form-groups\">

                        <input type=\"submit\" value=\"Ajouter\"  class=\"btn btn-info mt-sm-4\"/>

                    </div>
                </div>
            </form>

            <div id=\"sortable\" class=\"sortable-code ml-0\">
                <p>Solution</p>

                <ul id=\"ul-sortable\" class=\"ui-sortable output\">
                    <br>
                </ul>
            </div>
        </div>
    </div>
{% endblock %}
{% block javascripts %}
    {{ parent() }}
    <script src=\"{{asset('plugin/parson/lib/jquery.min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/jquery-ui.min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/jquery.ui.touch-punch.min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/underscore-min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/lis.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/parsons.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/skulpt.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/skulpt-stdlib.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/prettify.js')}}\"></script>
    <script>
        var il = \$(\"#sol\").html();

        var tasks = JSON.parse(il);
        addOldLine();
        function htmlEntities(str) {
            return String(str)
                    .replace(/&/g, \"&amp;\")
                    .replace(/</g, \"&lt;\")
                    .replace(/>/g, \"&gt;\")
                    .replace(/\"/g, \"&quot;\");
        }
        var i = tasks.length;
        var initial = \"\";
        function addLine() {
            \$(\"#ul-sortable\").empty();
            initial = \"\"
            tasks.forEach(task => {
                let levels = \"\";
                levels = \"\\xa0\\xa0\".repeat(parseInt(task.level));
                let lineToAdd = levels + task.lineText + \"\\n\";
                initial = initial + lineToAdd;
                \$(\"#ul-sortable\").append(`<li
                                        id=\"sortablecodeline\${20}\"
                                        class=\"prettyprint lang-py\"
                                        style=\"margin-left: \${50 * task.level}px;\"
                                        >\${task.lineText}
                                        <span style=\"float:right;\" onclick=\"deleteItem(this,\${task.position})\" class=\"btn btn-danger btn-sm\">x</span>
                                    </li>`);
            })
            majSolutionInput(JSON.stringify(tasks))
        }
        function majSolutionInput(vl) {
            \$(\"#task_solution\").val(\"\");
            \$(\"#task_solution\").val(vl);
        }
        function displayErrors(fb) {
            if (fb.errors.length > 0) {
                alert(fb.errors[0]);
            }
        }
        function addOldLine() {
            \$(\"#ul-sortable\").empty();
            tasks.forEach(task => {
                let levels = \"\";
                levels = \"\\xa0\\xa0\".repeat(parseInt(task.level));
                let lineToAdd = levels + htmlEntities(task.lineText) + \"\\n\";
                \$(\"#ul-sortable\").append(`<li
                                        id=\"sortablecodeline\${20}\"
                                        class=\"prettyprint lang-py\"
                                        style=\"margin-left: \${50 * task.level}px;\"
                                        >\${task.lineText}
                            <span style=\"float:right;\" onclick=\"deleteItem(this,\${task.position})\" class=\"btn btn-danger btn-sm\">x</span>
                                    </li>`);
            })
        }
        \$(document).ready(function () {
            var parson = new ParsonsWidget({
                sortableId: \"sortable\",
                trashId: \"sortableTrash\",
                max_wrong_lines: 1,
                feedback_cb: displayErrors,
            });

            function clearAddLineForm() {
                \$(\"#lineText\").val(\"\");
                \$(\"#level\").val(\"0\");
            }

            \$(\"#addLineForm\").submit(function (e) {
                event.preventDefault();
                let line = {};
                let a = \$(this).serializeArray();
                a.forEach((aa) => {
                    line[aa.name] = aa.value;
                });
                tasks.push({lineText: line.lineText, level: line.level, position: i})
                addLine();
                i++;
                clearAddLineForm();
            });
        });
        function deleteItem(a, ind) {
            \$(a).parent().remove();
            tasks = \$.grep(tasks, function (e) {
                return e.position != ind;
            });
            addLine();
            majSolutionInput(JSON.stringify(tasks));
        }
    </script>

{% endblock %}
", "task/edit.html.twig", "C:\\Users\\medab\\Desktop\\EDUCATION\\parson\\templates\\task\\edit.html.twig");
    }
}
