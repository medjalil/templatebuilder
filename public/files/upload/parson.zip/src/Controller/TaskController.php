<?php

namespace App\Controller;

use App\Entity\Course;
use App\Entity\Task;
use App\Form\TaskType;
use App\Repository\TaskRepository;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/task")
 */
class TaskController extends AbstractController {

    /**
     * @Route("/", name="task_index", methods={"GET"})
     */
    public function index(TaskRepository $taskRepository, PaginatorInterface $paginator, Request $request): Response {
        $resultat = $taskRepository->findAll();
        $tasks = $paginator->paginate($resultat, $request->query->getInt('page', 1), 2);
        return $this->render('task/index.html.twig', [
                    'tasks' => $tasks,
        ]);
    }

    /**
     * @Route("/{id}/new", name="task_new", methods={"GET","POST"})
     */
    public function new(Request $request, $id): Response {
        $entityManager = $this->getDoctrine()->getManager();
        $course = $entityManager->getRepository('App:Course')->find($id);
        $task = new Task();
        $form = $this->createForm(TaskType::class, $task);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $task->setCourse($course);
            $entityManager->persist($task);
            $entityManager->flush();

            return $this->redirectToRoute('course_show', ['id' => $id]);
        }

        return $this->render('task/new.html.twig', [
                    'task' => $task,
                    'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="task_show", methods={"GET","POST"})
     */
    public function show(Task $task): Response {

        return $this->render('task/show.html.twig', [
                    'task' => $task,
        ]);
    }

    /**
     * @Route("/{course}/{id}/edit", name="task_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Task $task, Course $course): Response {
        $form = $this->createForm(TaskType::class, $task);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('course_show', ['id' => $course->getId()]);
        }

        return $this->render('task/edit.html.twig', [
                    'task' => $task,
                    'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{course}/{id}", name="task_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Task $task, Course $course): Response {
        if ($this->isCsrfTokenValid('delete' . $task->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($task);
            $entityManager->flush();
        }

        return $this->redirectToRoute('course_show', ['id' => $course->getId()]);
    }

}
