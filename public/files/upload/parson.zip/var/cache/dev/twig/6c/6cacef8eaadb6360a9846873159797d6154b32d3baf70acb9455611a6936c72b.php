<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* task/new.html.twig */
class __TwigTemplate_c8eb104dc58d457b1e4c6a9f7e83c291dfd35251eae1950b2a886f4b5cf4b2c8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "task/new.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "task/new.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "task/new.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Ajouter exercice";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/parsons.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/prettify.css"), "html", null, true);
        echo "\">
    <script src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/prettify.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "    <div class=\"col-4\">
        <h1 class=\"h3 mb-3 font-weight-normal mt-4\">Ajouter exercice</h1>

        ";
        // line 14
        echo twig_include($this->env, $context, "task/_form.html.twig");
        echo "

    </div>
    <form id=\"addLineForm\">
        <label for=\"line\"> line text</label>
        <input type=\"text\" name=\"lineText\" id=\"lineText\" required/>
        <label for=\"level\">level</label>

        <input type=\"number\" name=\"level\" id=\"level\" value=\"0\" min=\"0\" required/>
        <input type=\"submit\" value=\"add Line\" />
    </form>
    ";
        // line 26
        echo "    <div id=\"sortable\" class=\"sortable-code\">
        <p>Construct your solution here</p>
        <ul id=\"ul-sortable\" class=\"ui-sortable output\">
        </ul>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 32
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 33
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/jquery.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/jquery-ui.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/jquery.ui.touch-punch.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/underscore-min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/lis.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/parsons.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/skulpt.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/skulpt-stdlib.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugin/parson/lib/prettify.js"), "html", null, true);
        echo "\"></script>
    <script>
        var tasks = [];
        var i = 0;
        var initial = \"\";

        function htmlEntities(str) {
            return String(str)
                    .replace(/&/g, \"&amp;\")
                    .replace(/</g, \"&lt;\")
                    .replace(/>/g, \"&gt;\")
                    .replace(/\"/g, \"&quot;\");
        }
        function addLine() {
            \$(\"#ul-sortable\").empty();
            initial = \"\"

            tasks.forEach(task => {

                let levels = \"\";
                levels = \"\\xa0\\xa0\".repeat(parseInt(task.level));
                let lineToAdd = levels + htmlEntities(task.lineText) + \"\\n\";
                console.log(\"line = \" + lineToAdd);
                initial = initial + lineToAdd;
                //console.log(i);
                //console.log(this.initial);
                \$(\"#ul-sortable\").append(`<li
                                        id=\"sortablecodeline\${20}\"
                                        class=\"prettyprint lang-py\"
                                        style=\"margin-left: \${50 * task.level}px;\"
                                        >\${task.lineText}
                                        <span style=\"float:right;\" onclick=\"deleteItem(this,\${task.position})\" class=\"btn btn-danger btn-sm\">x</span>
                                    </li>`);
            })


            majSolutionInput(JSON.stringify(tasks))
            //parson.init(initial);
            //parson.shuffleLines();
        }
        function majSolutionInput(vl) {
            \$(\"#task_solution\").val(\"\");
            \$(\"#task_solution\").val(vl);
            console.log(\$(\"#task_solution\").val());
        }
        function displayErrors(fb) {
            if (fb.errors.length > 0) {
                alert(fb.errors[0]);
            }
        }

        \$(document).ready(function () {
            var parson = new ParsonsWidget({
                sortableId: \"sortable\",
                trashId: \"sortableTrash\",
                max_wrong_lines: 1,
                feedback_cb: displayErrors,
            });

            function clearAddLineForm() {
                \$(\"#lineText\").val(\"\");
                \$(\"#level\").val(\"0\");
            }

            \$(\"#addLineForm\").submit(function (e) {
                event.preventDefault();
                let line = {};
                let a = \$(this).serializeArray();
                a.forEach((aa) => {
                    line[aa.name] = aa.value;
                });

                tasks.push({lineText: line.lineText, level: line.level, position: i})
                addLine();
                i++;
                console.log(tasks);

                clearAddLineForm();
            });
        });
        function deleteItem(a, ind) {
            \$(a).parent().remove();
            tasks = \$.grep(tasks, function (e) {
                return e.position != ind;
            });
            console.log(\"after remove\")
            console.log(JSON.stringify(tasks));
            addLine();
            majSolutionInput(JSON.stringify(tasks));
        }
    </script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "task/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  206 => 42,  202 => 41,  198 => 40,  194 => 39,  190 => 38,  186 => 37,  182 => 36,  178 => 35,  174 => 34,  169 => 33,  159 => 32,  144 => 26,  130 => 14,  125 => 11,  115 => 10,  103 => 8,  99 => 7,  95 => 6,  90 => 5,  80 => 4,  61 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Ajouter exercice{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('plugin/parson/parsons.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('plugin/parson/lib/prettify.css') }}\">
    <script src=\"{{asset('plugin/parson/lib/prettify.js')}}\"></script>
{% endblock %}
{% block body %}
    <div class=\"col-4\">
        <h1 class=\"h3 mb-3 font-weight-normal mt-4\">Ajouter exercice</h1>

        {{ include('task/_form.html.twig') }}

    </div>
    <form id=\"addLineForm\">
        <label for=\"line\"> line text</label>
        <input type=\"text\" name=\"lineText\" id=\"lineText\" required/>
        <label for=\"level\">level</label>

        <input type=\"number\" name=\"level\" id=\"level\" value=\"0\" min=\"0\" required/>
        <input type=\"submit\" value=\"add Line\" />
    </form>
    {#task_solution#}
    <div id=\"sortable\" class=\"sortable-code\">
        <p>Construct your solution here</p>
        <ul id=\"ul-sortable\" class=\"ui-sortable output\">
        </ul>
    </div>
{% endblock %}
{% block javascripts %}
    {{ parent() }}
    <script src=\"{{asset('plugin/parson/lib/jquery.min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/jquery-ui.min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/jquery.ui.touch-punch.min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/underscore-min.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/lis.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/parsons.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/skulpt.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/skulpt-stdlib.js')}}\"></script>
    <script src=\"{{asset('plugin/parson/lib/prettify.js')}}\"></script>
    <script>
        var tasks = [];
        var i = 0;
        var initial = \"\";

        function htmlEntities(str) {
            return String(str)
                    .replace(/&/g, \"&amp;\")
                    .replace(/</g, \"&lt;\")
                    .replace(/>/g, \"&gt;\")
                    .replace(/\"/g, \"&quot;\");
        }
        function addLine() {
            \$(\"#ul-sortable\").empty();
            initial = \"\"

            tasks.forEach(task => {

                let levels = \"\";
                levels = \"\\xa0\\xa0\".repeat(parseInt(task.level));
                let lineToAdd = levels + htmlEntities(task.lineText) + \"\\n\";
                console.log(\"line = \" + lineToAdd);
                initial = initial + lineToAdd;
                //console.log(i);
                //console.log(this.initial);
                \$(\"#ul-sortable\").append(`<li
                                        id=\"sortablecodeline\${20}\"
                                        class=\"prettyprint lang-py\"
                                        style=\"margin-left: \${50 * task.level}px;\"
                                        >\${task.lineText}
                                        <span style=\"float:right;\" onclick=\"deleteItem(this,\${task.position})\" class=\"btn btn-danger btn-sm\">x</span>
                                    </li>`);
            })


            majSolutionInput(JSON.stringify(tasks))
            //parson.init(initial);
            //parson.shuffleLines();
        }
        function majSolutionInput(vl) {
            \$(\"#task_solution\").val(\"\");
            \$(\"#task_solution\").val(vl);
            console.log(\$(\"#task_solution\").val());
        }
        function displayErrors(fb) {
            if (fb.errors.length > 0) {
                alert(fb.errors[0]);
            }
        }

        \$(document).ready(function () {
            var parson = new ParsonsWidget({
                sortableId: \"sortable\",
                trashId: \"sortableTrash\",
                max_wrong_lines: 1,
                feedback_cb: displayErrors,
            });

            function clearAddLineForm() {
                \$(\"#lineText\").val(\"\");
                \$(\"#level\").val(\"0\");
            }

            \$(\"#addLineForm\").submit(function (e) {
                event.preventDefault();
                let line = {};
                let a = \$(this).serializeArray();
                a.forEach((aa) => {
                    line[aa.name] = aa.value;
                });

                tasks.push({lineText: line.lineText, level: line.level, position: i})
                addLine();
                i++;
                console.log(tasks);

                clearAddLineForm();
            });
        });
        function deleteItem(a, ind) {
            \$(a).parent().remove();
            tasks = \$.grep(tasks, function (e) {
                return e.position != ind;
            });
            console.log(\"after remove\")
            console.log(JSON.stringify(tasks));
            addLine();
            majSolutionInput(JSON.stringify(tasks));
        }
    </script>

{% endblock %}", "task/new.html.twig", "C:\\Users\\medab\\Desktop\\EDUCATION\\parson\\templates\\task\\new.html.twig");
    }
}
