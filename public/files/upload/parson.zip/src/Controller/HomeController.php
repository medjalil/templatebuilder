<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController {

    /**
     * @Route("/", name="homepage")
     */
    public function index() {
        return $this->render('home/index.html.twig');
    }

    /**
     * @Route("/profile", name="app_profile")
     */
    public function showProfile() {
        return $this->render('profile/index.html.twig');
    }

}
